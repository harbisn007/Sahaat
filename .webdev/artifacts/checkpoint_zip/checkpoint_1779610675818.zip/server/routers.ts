import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import {
  emitRoomUpdated,
  emitRoomDeleted,
  emitParticipantJoined,
  emitParticipantLeft,
  emitJoinRequestCreated,
  emitJoinRequestResponded,
  emitAudioMessageCreated,
  emitRecordingStatusChanged,
  emitKhaloohaCommand,
  emitPublicInviteCreated,
  emitPublicInviteExpired,
  getOnlineUsersCount,
  getActiveUsersCount,
  recordUserActivity,
  emitSufoofSoundUpdated,
  emitPlayAudioMessage,
  emitPlaySheeloha,
  emitCreatorJoinRequest,
  getOnlineUserIds,
  getUserCurrentRoomId,
  emitInteractionUpdated,
  addRoomLikeDislike,
  getRoomLikeDislike,
  clearRoomLikes,
  emitReactionCreated,
  emitUserBanned,
  emitTextMessageCreated,
} from "./_core/socket";
// تم إلغاء معالجة الجوقة - الصوت الأصلي يُستخدم دائماً

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),

    // البحث عن مستخدم برقم الجوال
    getUserByPhone: publicProcedure
      .input(z.object({ phoneNumber: z.string() }))
      .query(async ({ input }) => {
        const user = await db.getUserByPhone(input.phoneNumber);
        if (!user) return null;
        return {
          openId: user.openId,
          name: user.name,
          avatar: user.avatar,
          phoneNumber: user.phoneNumber,
        };
      }),

    // حفظ مستخدم جديد برقم الجوال
    upsertUserByPhone: publicProcedure
      .input(z.object({
        phoneNumber: z.string(),
        name: z.string(),
        avatar: z.string(),
        openId: z.string(),
        appUserId: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.upsertUserByPhone(input);
        return { success: true };
      }),
  }),

  // Rooms router
  rooms: router({
    // Get rooms with pagination - محسّن للتوسع
    list: publicProcedure
      .input(z.object({ 
        page: z.number().default(1),
        limit: z.number().default(20)
      }).optional())
      .query(async ({ input }) => {
        const page = input?.page || 1;
        const limit = input?.limit || 20;
        return db.getRoomsWithPagination(page, limit);
      }),

    // Get room by ID with participants - محسّن لاستخدام استعلامين فقط
    getById: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        // استخدام الدالة المحسّنة التي تجلب كل شيء في استعلامين
        return db.getRoomWithAllData(input.roomId);
      }),

    // Create a new room
    create: publicProcedure
      .input(
        z.object({
          name: z.string().min(3).max(100),
          creatorId: z.string(),
          creatorName: z.string().min(3).max(50),
          creatorAvatar: z.string().default("male"),
        })
      )
      .mutation(async ({ input }) => {
        // التحقق من الحظر قبل إنشاء الساحة
        const banCheck = await db.checkActiveBan(input.creatorId);
        if (banCheck.isBanned) {
          throw new Error("أنت محظور ولا يمكنك إنشاء ساحة.");
        }
        // حذف أي ساحة قديمة لنفس المنشئ قبل إنشاء ساحة جديدة
        // هذا يمنع وجود ساحات يتيمة عند حذف التطبيق وإعادة تثبيته
        const existingRoom = await db.getUserActiveRoom(input.creatorId);
        if (existingRoom) {
          console.log(`[Rooms] Deleting old room ${existingRoom.id} for creator ${input.creatorId} before creating new one`);
          emitRoomDeleted(existingRoom.id, existingRoom.name);
          await db.deleteRoom(existingRoom.id);
        }

        const roomId = await db.createRoom({
          name: input.name,
          creatorId: input.creatorId,
          creatorName: input.creatorName,
          creatorAvatar: input.creatorAvatar,
          isActive: "true",
          createdAt: new Date(), // ضبط وقت الإنشاء صراحةً
          lastPlayerLeftAt: null, // إعادة ضبط وقت خروج اللاعب
          extensionLostAt: null, // إعادة ضبط وقت فقدان التمديد
        });

        // Add creator as a player
        await db.addParticipant({
          roomId: Number(roomId),
          userId: input.creatorId,
          username: input.creatorName,
          avatar: input.creatorAvatar,
          role: "creator",
          status: "accepted",
        });

        return { roomId };
      }),

    // Request to join as player
    requestJoinAsPlayer: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string().min(3).max(50),
          avatar: z.string().default("male"),
        })
      )
      .mutation(async ({ input }) => {
        // التحقق من الحظر
        const banCheck = await db.checkActiveBan(input.userId);
        if (banCheck.isBanned) {
          throw new Error("أنت محظور ولا يمكنك دخول الساحات.");
        }
        // Remove any existing participant record for this user in this room
        // This ensures returning players start fresh with "pending" status
        await db.removeParticipant(input.roomId, input.userId);

        // Check if room already has 1 additional player (creator + 1 player = 2 total)
        const playerCount = await db.getPlayerCount(input.roomId);
        if (playerCount >= 1) {
          throw new Error("Room is full");
        }

        const participantId = await db.addParticipant({
          roomId: input.roomId,
          userId: input.userId,
          username: input.username,
          avatar: input.avatar,
          role: "player",
          status: "pending",
        });

        // إرسال إشعار للمنشئ عبر قناته الخاصة (طلب انضمام كلاعب)
        const room = await db.getRoomById(input.roomId);
        if (room) {
          emitCreatorJoinRequest(
            input.roomId,
            room.creatorId,
            "player",
            input.userId,
            input.username
          );
        }

        // حذف تلقائي بعد 15 ثانية من الإنشاء (تحويل لمشاهد)
        setTimeout(async () => {
          try {
            const participant = await db.getParticipantById(participantId);
            if (participant && participant.status === "pending") {
              console.log(`[AutoExpire] Auto-expiring player request ${participantId} after 15s`);
              // تحويل اللاعب المعلق إلى مشاهد (نفس منطق الرفض)
              await db.updateParticipantRole(participantId, "viewer");
              await db.updateParticipantStatus(participantId, "accepted");
              emitRoomUpdated(input.roomId);
            }
          } catch (e) {
            console.warn(`[AutoExpire] Error expiring player request ${participantId}:`, e);
          }
        }, 15000);

        return { participantId };
      }),

    // Join as viewer (direct, no approval needed)
    joinAsViewer: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string().min(3).max(50),
          avatar: z.string().default("male"),
        })
      )
      .mutation(async ({ input }) => {
        // التحقق من الحظر
        const banCheck = await db.checkActiveBan(input.userId);
        if (banCheck.isBanned) {
          throw new Error("أنت محظور ولا يمكنك دخول الساحات.");
        }
        // التحقق من أن المستخدم ليس منشئ الساحة
        const room = await db.getRoomById(input.roomId);
        if (room && room.creatorId === input.userId) {
          throw new Error("لا يمكنك الدخول كمشاهد في ساحتك");
        }
        
        // Remove any existing participant record for this user in this room
        await db.removeParticipant(input.roomId, input.userId);

        const participantId = await db.addParticipant({
          roomId: input.roomId,
          userId: input.userId,
          username: input.username,
          avatar: input.avatar,
          role: "viewer",
          status: "accepted",
        });

        // التحقق من منح النجمة الذهبية (إذا تجاوز عدد المشاهدين 20)
        await db.checkAndAwardGoldStar(input.roomId);

        // إرسال إشعار للمنشئ عبر قناته الخاصة (دخول مستمع)
        if (room) {
          emitCreatorJoinRequest(
            input.roomId,
            room.creatorId,
            "viewer",
            input.userId,
            input.username
          );
        }

        return { participantId };
      }),

    // Get pending player requests for a room
    getPendingRequests: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getPendingPlayerRequests(input.roomId);
      }),

    // Accept or reject player request
    respondToRequest: publicProcedure
      .input(
        z.object({
          participantId: z.number(),
          accept: z.boolean(),
        })
      )
      .mutation(async ({ input }) => {
        // Get participant info to find roomId
        const participant = await db.getParticipantById(input.participantId);
        if (!participant) {
          throw new Error("Participant not found");
        }

        if (input.accept) {
          // Accept the request
          await db.updateParticipantStatus(input.participantId, "accepted");
          
          // If accepting a player, check if we've reached the limit (2 players)
          if (participant.role === "player") {
            const acceptedPlayersCount = await db.getAcceptedPlayersCount(participant.roomId);
            
            // If we now have 2 players, reject all other pending player requests
            if (acceptedPlayersCount >= 2) {
              await db.rejectAllPendingPlayerRequests(participant.roomId);
            }
          }
        } else {
          // Reject the request - convert player to viewer
          if (participant.role === "player") {
            await db.updateParticipantRole(input.participantId, "viewer");
            await db.updateParticipantStatus(input.participantId, "accepted");
          } else {
            await db.updateParticipantStatus(input.participantId, "rejected");
          }
        }

        // بث الرد على طلب الانضمام لقناة المستخدم الشخصية
        emitJoinRequestResponded(
          participant.roomId,
          input.participantId,
          input.accept,
          participant.userId
        );
        
        // بث تحديث الساحة لجميع المشاركين
        emitRoomUpdated(participant.roomId);
        
        return { success: true };
      }),

    // Leave room (for players and viewers)
    leaveRoom: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          role: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.removeParticipant(input.roomId, input.userId);
        
        // تحديث وقت خروج آخر لاعب (لحساب مدة الحذف التلقائي)
        if (input.role === "player") {
          await db.updateLastPlayerLeftTime(input.roomId);
        }
        
        // بث مغادرة المشارك لجميع المشاركين
        emitParticipantLeft(input.roomId, input.userId);
        emitRoomUpdated(input.roomId);
        
        return { success: true };
      }),

    // Delete room (for creator only)
    deleteRoom: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        // الحصول على اسم الساحة قبل الحذف
        const room = await db.getRoomById(input.roomId);
        const roomName = room?.name || "ساحة غير معروفة";
        
        // بث حذف الساحة لجميع المشاركين قبل الحذف
        emitRoomDeleted(input.roomId, roomName);
        // حذف بيانات الإعجاب من الذاكرة عند إغلاق الساحة
        clearRoomLikes(input.roomId);
        
        await db.deleteRoom(input.roomId);
        return { success: true, roomName };
      }),

    // Get user's active room
    getUserActiveRoom: publicProcedure
      .input(
        z.object({
          creatorId: z.string(),
        })
      )
      .query(async ({ input }) => {
        const activeRoom = await db.getUserActiveRoom(input.creatorId);
        return activeRoom;
      }),

    // Get room control state (taroukController + clappingDelay)
    getControlState: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getRoomControlState(input.roomId);
      }),

    // Update tarouk controller
    setTaroukController: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          controller: z.enum(["creator", "player1", "player2"]).nullable(),
        })
      )
      .mutation(async ({ input }) => {
        await db.updateTaroukController(input.roomId, input.controller);
        // بث التغيير لجميع المشاركين
        emitRoomUpdated(input.roomId);
        return { success: true };
      }),

    // Update clapping delay
    setClappingDelay: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          delay: z.number().min(0.05).max(1.5),
        })
      )
      .mutation(async ({ input }) => {
        await db.updateClappingDelay(input.roomId, input.delay);
        // بث التغيير لجميع المشاركين
        emitRoomUpdated(input.roomId);
        return { success: true };
      }),
  }),

  // Audio messages router
  audio: router({
    // Get all audio messages for a room
    list: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getRoomAudioMessages(input.roomId);
      }),

    // Add a new audio message
    create: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string(),
          messageType: z.enum(["comment", "tarouk"]),
          audioUrl: z.string(),
          duration: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        console.log(`[audio.create] Type: ${input.messageType}, Duration: ${input.duration}s`);
        
        const messageId = await db.addAudioMessage(input);
        const now = new Date();
        
        // بث الرسالة الصوتية الجديدة لجميع المشاركين (لتحديث القائمة)
        emitAudioMessageCreated(
          input.roomId,
          messageId,
          input.userId,
          input.username,
          input.messageType,
          input.audioUrl,
          input.duration,
          now
        );
        
        // بث أمر تشغيل الطاروق/التعليق عند الجميع (ما عدا المرسل - يشغل محلياً)
        emitPlayAudioMessage(
          input.roomId,
          messageId,
          input.audioUrl,
          input.messageType,
          input.userId,
          input.username,
          now.getTime(), // startTime as timestamp
          input.duration
        );
        
        // الشيلوها تُولَّد فقط عند ضغط زر شيلوها - لا توليد تلقائي
        
        return { messageId };
      }),

    // Get last tarouk message
    getLastTarouk: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getLastTaroukMessage(input.roomId);
      }),

    // Generate sheeloha for a tarouk
    generateSheeloha: publicProcedure
      .input(
        z.object({
          taroukBase64: z.string(),
          taroukDuration: z.number(),
          roomId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        console.log(`[audio.generateSheeloha] Generating sheeloha, duration: ${input.taroukDuration}s`);
        
        try {
          const { generateSheeloha } = await import("./sheeloha-generator");
          const sheelohaUrl = await generateSheeloha({
            taroukBase64: input.taroukBase64,
            taroukDuration: input.taroukDuration,
          });
          
          console.log(`[audio.generateSheeloha] Sheeloha generated: ${sheelohaUrl}`);
          return { sheelohaUrl };
        } catch (error: any) {
          console.error(`[audio.generateSheeloha] Failed:`, error);
          console.error(`[audio.generateSheeloha] Error message:`, error.message);
          console.error(`[audio.generateSheeloha] Error stack:`, error.stack);
          throw new Error(`Failed to generate sheeloha: ${error.message}`);
        }
      }),
  }),

  // Upload audio file
  uploadAudio: publicProcedure
    .input(
      z.object({
        base64Data: z.string(),
        fileName: z.string(),
        speedUp: z.boolean().optional(), // تسريع الصوت بنسبة 1.15 للطاروق
      })
    )
    .mutation(async ({ input }) => {
      const { storagePut } = await import("./storage");
      
      // تنظيف base64 من data URL prefix إن وجد
      const base64Clean = input.base64Data.replace(/^data:audio\/\w+;base64,/, '');
      const buffer: Buffer = Buffer.from(base64Clean, "base64");
      
      if (buffer.length === 0) throw new Error('الملف الصوتي فارغ');

      // تحديد ContentType بناءً على اسم الملف
      const isWebm = input.fileName.endsWith('.webm');
      const contentType = isWebm ? 'audio/webm' : 'audio/mp4';

      // Generate unique file key
      const timestamp = Date.now();
      const randomSuffix = Math.random().toString(36).substring(7);
      const fileKey = `audio/${timestamp}-${randomSuffix}-${input.fileName}`;
      
      // رفع الصوت على S3
      const { url } = await storagePut(fileKey, buffer, contentType);
      console.log("[uploadAudio] Audio uploaded:", url);
      
      return { url };
    }),

  // Reactions router
  reactions: router({
    // Add a reaction
    create: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string(),
          reactionType: z.enum([
            // الصف الأول — شخصيات
            "clapping",
            "laughing",
            "angry",
            "thumbsup",
            // الصف الثاني — نصية
            "salam",
            "alaikum",
            "masaakum",
            "masa_alnoor",
            // الصف الثالث — نصية
            "hayak",
            "abqak",
            "sah_lisanak",
            "kafo",
            // الصف الرابع — نصية
            "maalaik_zood",
            "malak_lowa",
            "latoodha",
            "eid_karrar",
            // للتوافق مع القديم
            "clap", "fire", "heart", "star", "laugh", "wow", "thinking", "sad",
            "check", "cross", "thumbsdown", "strong", "celebrate", "love",
          ]),
        })
      )
      .mutation(async ({ input }) => {
        try {
          console.log("[API] Creating reaction:", input);
          const reactionId = await db.addReaction(input);
          console.log("[API] Reaction created with ID:", reactionId);
          
          // بث التفاعل الجديد لجميع المشاركين
          emitReactionCreated(
            input.roomId,
            reactionId,
            input.userId,
            input.username,
            input.reactionType,
            new Date()
          );
          
          return { reactionId };
        } catch (error) {
          console.error("[API] Failed to create reaction:", error);
          throw new Error("فشل حفظ التفاعل في قاعدة البيانات");
        }
      }),

    // Get recent reactions for a room
    getRecent: publicProcedure
      .input(z.object({ roomId: z.number(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        return db.getRecentReactions(input.roomId, input.limit);
      }),

    // List all reactions for a room
    list: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getRecentReactions(input.roomId, 100);
      }),
  }),

  // Khalooha commands router
  khalooha: router({
    // Create a khalooha command (when someone presses "خلوها" button)
    stop: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          console.log("[API] Creating khalooha command:", input);
          const commandId = await db.createKhaloohaCommand(input);
          console.log("[API] Khalooha command created with ID:", commandId);
          
          // بث خلوها لجميع المشاركين
          emitKhaloohaCommand(
            input.roomId,
            input.userId,
            input.username,
            new Date()
          );
          
          return { commandId };
        } catch (error) {
          console.error("[API] Failed to create khalooha command:", error);
          throw new Error("فشل إيقاف شيلوها");
        }
      }),

    // Get latest khalooha command for a room
    latest: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getLatestKhaloohaCommand(input.roomId);
      }),
  }),

  // Recording status router (for showing "طاروق..." indicator)
  recording: router({
    // Set recording status (start/stop)
    setStatus: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string(),
          isRecording: z.boolean(),
          recordingType: z.enum(["comment", "tarouk"]),
        })
      )
      .mutation(async ({ input }) => {
        try {
          console.log("[API] Setting recording status:", input);
          await db.setRecordingStatus(input);
          
          // بث تغيير حالة التسجيل لجميع المشاركين
          emitRecordingStatusChanged(
            input.roomId,
            input.userId,
            input.username,
            input.isRecording,
            input.recordingType
          );
          
          return { success: true };
        } catch (error) {
          console.error("[API] Failed to set recording status:", error);
          throw new Error("فشل تحديث حالة التسجيل");
        }
      }),

    // Get active recordings in a room
    getActive: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getActiveRecordings(input.roomId);
      }),

    // Clear recording status
    clear: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        await db.clearRecordingStatus(input.roomId, input.userId);
        
        // بث إيقاف التسجيل لجميع المشاركين عبر Socket.io
        emitRecordingStatusChanged(
          input.roomId,
          input.userId,
          "", // username غير مطلوب عند الإيقاف
          false,
          "" // recordingType غير مطلوب عند الإيقاف
        );
        
        return { success: true };
      }),
  }),

  // Join requests router (for viewers requesting to become players)
  joinRequests: router({
    // Create a join request (viewer only)
    create: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string(),
          avatar: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const requestId = await db.createJoinRequest(input);
          
          // بث طلب الانضمام الجديد للمنشئ (داخل الساحة)
          emitJoinRequestCreated(
            input.roomId,
            requestId,
            input.userId,
            input.username,
            input.avatar
          );
          
          // إرسال إشعار للمنشئ عبر قناته الخاصة (خارج الساحة)
          const room = await db.getRoomById(input.roomId);
          if (room) {
            emitCreatorJoinRequest(
              input.roomId,
              room.creatorId,
              "player",
              input.userId,
              input.username
            );
          }
          
          // حذف تلقائي بعد 15 ثانية من الإنشاء
          setTimeout(async () => {
            try {
              const requests = await db.getPendingJoinRequests(input.roomId);
              const req = requests.find((r: any) => r.id === requestId);
              if (req) {
                console.log(`[AutoExpire] Auto-expiring join request ${requestId} after 15s`);
                await db.expireJoinRequest(requestId);
                emitRoomUpdated(input.roomId);
              }
            } catch (e) {
              console.warn(`[AutoExpire] Error expiring join request ${requestId}:`, e);
            }
          }, 15000);

          return { success: true, requestId };
        } catch (error: any) {
          throw new Error(error.message || "فشل إرسال الطلب");
        }
      }),

    // Get pending requests for a room (creator only)
    getPending: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.getPendingJoinRequests(input.roomId);
      }),

    // Respond to a join request (creator only)
    respond: publicProcedure
      .input(
        z.object({
          requestId: z.number(),
          accept: z.boolean(),
          roomId: z.number(),
          userId: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const request = await db.respondToJoinRequest(input.requestId, input.accept);
          
          if (input.accept) {
            // Check if room has space for another player
            const acceptedCount = await db.getAcceptedPlayersCount(input.roomId);
            if (acceptedCount >= 2) {
              throw new Error("الساحة ممتلئة باللاعبين");
            }
            // Promote viewer to player (use request data for username and avatar)
            await db.promoteViewerToPlayer(input.roomId, request.userId, request.username, request.avatar);
            // تحديث وقت آخر لاعب منضم (لحساب مدة الحذف التلقائي)
            await db.updateLastPlayerJoinTime(input.roomId);
          }
          
          // بث الرد على طلب الانضمام لجميع المشاركين
          emitJoinRequestResponded(
            input.roomId,
            input.requestId,
            input.accept,
            request.userId
          );
          
          // بث تحديث الساحة
          emitRoomUpdated(input.roomId);
          
          return { success: true, request };
        } catch (error: any) {
          throw new Error(error.message || "فشل الرد على الطلب");
        }
      }),

    // Expire a request (auto-expire after 4 seconds)
    expire: publicProcedure
      .input(z.object({ requestId: z.number() }))
      .mutation(async ({ input }) => {
        await db.expireJoinRequest(input.requestId);
        return { success: true };
      }),
  }),

  // Update participant profile
  profile: router({
    update: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          userId: z.string(),
          username: z.string().min(2).max(20),
          avatar: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await db.updateParticipantProfile(
            input.roomId,
            input.userId,
            input.username,
            input.avatar
          );
          return { success: true };
        } catch (error: any) {
          throw new Error(error.message || "فشل تحديث الملف الشخصي");
        }
      }),
  }),

  // Kick player router (creator only)
  kick: router({
    player: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          playerId: z.string(),
          creatorId: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await db.kickPlayer(input.roomId, input.playerId, input.creatorId);
          return { success: true };
        } catch (error: any) {
          throw new Error(error.message || "فشل استبعاد اللاعب");
        }
      }),
  }),

  // Top 10 rooms router
  top10: router({
    // Get top 10 rooms sorted by viewers, pending requests, players, then oldest
    list: publicProcedure.query(async () => {
      return db.getTop10Rooms();
    }),
  }),

  // Online users count
  stats: router({
    // Get online users count (actual + 50%)
    onlineCount: publicProcedure.query(() => {
      const actualCount = getActiveUsersCount();
      // الرقم المعروض = العدد الفعلي + 50% (رقم صحيح)
      const displayCount = Math.floor(actualCount * 1.5);
      return { count: displayCount };
    }),
    
    // تسجيل نشاط المستخدم (heartbeat)
    heartbeat: publicProcedure
      .input(z.object({ userId: z.string() }))
      .mutation(({ input }) => {
        recordUserActivity(input.userId);
        return { success: true };
      }),
  }),

  // Public invitations router
  publicInvitations: router({
    // Create a public invitation (creator only, 5 min cooldown)
    create: publicProcedure
      .input(
        z.object({
          roomId: z.number(),
          creatorId: z.string(),
          creatorName: z.string(),
          creatorAvatar: z.string(),
          roomName: z.string(),
          message: z.string().max(70).optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Check cooldown
        const canSend = await db.canSendPublicInvite(input.roomId);
        if (!canSend) {
          throw new Error("يجب الانتظار 5 دقائق قبل إرسال دعوة عامة أخرى");
        }

        // Create invitation
        const invitationId = await db.createPublicInvitation({
          ...input,
          message: input.message || 'حياكم الله..',
        });
        
        // Update last invite time
        await db.updateLastPublicInviteTime(input.roomId);
        
        // Emit socket event for real-time update
        emitPublicInviteCreated(
          invitationId,
          input.roomId,
          input.creatorId,
          input.creatorName,
          input.creatorAvatar,
          input.roomName
        );
        
        return { success: true, invitationId };
      }),

    // Get pending invitations (for queue display)
    getPending: publicProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return db.getPendingPublicInvitations(input.limit);
      }),

    // Get displayed invitations (currently showing in top 10)
    getDisplayed: publicProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .query(async ({ input }) => {
        return db.getDisplayedPublicInvitations(input.limit);
      }),

    // Mark invitation as displayed
    markDisplayed: publicProcedure
      .input(z.object({ invitationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.markInvitationAsDisplayed(input.invitationId);
        return { success: true };
      }),

    // Expire invitation (after 4 seconds display)
    expire: publicProcedure
      .input(z.object({ invitationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.expirePublicInvitation(input.invitationId);
        
        // Emit socket event
        emitPublicInviteExpired(input.invitationId);
        
        return { success: true };
      }),

    // Check if can send public invite (5 min cooldown)
    canSend: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.canSendPublicInvite(input.roomId);
      }),
  }),

   // Gold star router
  goldStar: router({
    // Check and award gold star if room has > 20 viewers
    check: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .mutation(async ({ input }) => {
        const awarded = await db.checkAndAwardGoldStar(input.roomId);
        return { awarded };
      }),
  }),
  // User interactions router (like / follow / dislike)
  interactions: router({
    // تبديل تفاعل (إضافة أو إلغاء)
    // إضافة إعجاب أو عدم إعجاب بدون قيود (كل ضغطة +1)
    addLikeDislike: publicProcedure
      .input(z.object({
        fromUserId: z.string(),
        toUserId: z.string(),
        type: z.enum(["like", "dislike"]),
        roomId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        // لا نكتب في قاعدة البيانات - نحدّث in-memory فقط
        if (!input.roomId) return { success: true };
        const counts = addRoomLikeDislike(input.roomId, input.toUserId, input.type);
        // جلب عدد المتابعين من قاعدة البيانات (فقط follows)
        const stats = await db.getUserInteractionStats(input.toUserId, input.fromUserId);
        emitInteractionUpdated(input.roomId, input.toUserId, counts.likes, counts.dislikes, stats.follows);
        return { success: true };
      }),
    toggle: publicProcedure
      .input(z.object({
        fromUserId: z.string(),
        toUserId: z.string(),
        type: z.enum(["like", "follow", "dislike"]),
        roomId: z.number().optional(), // لإرسال socket event
      }))
      .mutation(async ({ input }) => {
        console.log('[INTERACTION] toggle called', input);
        if (input.fromUserId === input.toUserId) {
          throw new Error("لا يمكنك التفاعل مع نفسك");
        }
        const result = await db.toggleUserInteraction(input.fromUserId, input.toUserId, input.type);
        // بث socket event فوري لتحديث العدادات
        if (input.roomId) {
          const stats = await db.getUserInteractionStats(input.toUserId, input.fromUserId);
          emitInteractionUpdated(input.roomId, input.toUserId, stats.likes, stats.dislikes, stats.follows);
        }
        return result;
      }),
    // جلب إحصائيات التفاعل لمستخدم معين
    getStats: publicProcedure
      .input(z.object({
        toUserId: z.string(),
        fromUserId: z.string(),
      }))
      .query(async ({ input }) => {
        return db.getUserInteractionStats(input.toUserId, input.fromUserId);
      }),
    // جلب قائمة المتابَعين
    getFollowing: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        return db.getFollowing(input.userId);
      }),
    // جلب قائمة المتابِعين
    getFollowers: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        return db.getFollowers(input.userId);
      }),
    // جلب قائمة المتابَعين مع بياناتهم الكاملة (اسم + حالة اتصال + ساحة حالية)
    getFollowingDetails: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        const following = await db.getFollowing(input.userId);
        const onlineIds = getOnlineUserIds();
        const rooms = await db.getAllRooms();
        const roomMap = new Map(rooms.map((r: any) => [r.id, r.name]));
        // جلب IDs الذين حجبوا المستخدم الحالي (أي حجبوا input.userId)
        const blockedByIds = await db.getBlockedByIds(input.userId);
        const blockedBySet = new Set(blockedByIds);
        return following.map((f: any) => {
          const isOnline = onlineIds.has(f.toUserId);
          // إذا حجب هذا الشخص المستخدمَ الحالي → أخفِ الساحة
          const isBlockedByThem = blockedBySet.has(f.toUserId);
          const currentRoomId = isBlockedByThem ? null : getUserCurrentRoomId(f.toUserId);
          const currentRoomName = currentRoomId ? (roomMap.get(currentRoomId) || 'ساحات الطواريق') : 'ساحات الطواريق';
          return {
            userId: f.toUserId,
            username: f.toUsername || f.toUserId,
            avatar: f.toAvatar || null,
            isOnline,
            currentRoomId,
            currentRoomName,
          };
        });
      }),
    // جلب قائمة المتابِعين مع بياناتهم الكاملة
    getFollowersDetails: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        const followers = await db.getFollowers(input.userId);
        const onlineIds = getOnlineUserIds();
        const rooms = await db.getAllRooms();
        const roomMap = new Map(rooms.map((r: any) => [r.id, r.name]));
        return followers.map((f: any) => {
          const isOnline = onlineIds.has(f.fromUserId);
          const currentRoomId = getUserCurrentRoomId(f.fromUserId);
          const currentRoomName = currentRoomId ? (roomMap.get(currentRoomId) || 'ساحات الطواريق') : 'ساحات الطواريق';
          return {
            userId: f.fromUserId,
            username: f.fromUsername || f.fromUserId,
            avatar: f.fromAvatar || null,
            isOnline,
            currentRoomId,
            currentRoomName,
          };
        });
      }),
  }),

  // Reports & Bans router
  reports: router({
    // إرسال بلاغ
    submit: publicProcedure
      .input(z.object({
        reporterUserId: z.string(),
        reportedUserId: z.string(),
        audioMessageId: z.number().optional(),
        audioUrl: z.string(),
        textContent: z.string().optional(),
        messageType: z.enum(["comment", "tarouk"]),
        reason: z.enum(["offensive_content", "bad_behavior"]),
      }))
      .mutation(async ({ input }) => {
        const reporterUser = await db.getUserByAppUserId(input.reporterUserId);
        const reporterName = reporterUser?.name || input.reporterUserId;

        const reportedUser = await db.getUserByAppUserId(input.reportedUserId);
        const reportedName = reportedUser?.name || input.reportedUserId;

        return db.submitReport({ ...input, textContent: input.textContent, reporterName, reportedName });
      }),
    // جلب كل البلاغات (للإدارة)
    getAll: publicProcedure
      .query(async () => {
        return db.getAllReports();
      }),
    // حذف بلاغ
    delete: publicProcedure
      .input(z.object({ reportId: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteReport(input.reportId);
      }),
    // حظر مستخدم
    banUser: publicProcedure
      .input(z.object({
        userId: z.string(),
        username: z.string(),
        banType: z.enum(["1h", "24h", "permanent"]),
      }))
      .mutation(async ({ input }) => {
        const ban = await db.banUser(input.userId, input.username, input.banType);
        // إغلاق ساحة المحظور فوراً إن وُجدت
        const activeRoom = await db.getUserActiveRoom(input.userId);
        if (activeRoom) {
          console.log(`[Ban] Closing room ${activeRoom.id} for banned user ${input.userId}`);
          emitRoomDeleted(activeRoom.id, activeRoom.name);
          await db.deleteRoom(activeRoom.id);
        }
        emitUserBanned(input.userId, input.banType);
        return ban;
      }),
    // التحقق من حظر مستخدم
    checkBan: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => {
        return db.checkActiveBan(input.userId);
      }),
  }),
  // Blocking router
  blocking: router({
    toggle: publicProcedure
      .input(z.object({ blockerId: z.string(), blockedId: z.string() }))
      .mutation(async ({ input }) => {
        if (input.blockerId === input.blockedId) throw new Error("لا يمكنك حجب نفسك");
        return db.toggleBlock(input.blockerId, input.blockedId);
      }),

    isBlocked: publicProcedure
      .input(z.object({ blockerId: z.string(), blockedId: z.string() }))
      .query(async ({ input }) => {
        const blocked = await db.isBlocked(input.blockerId, input.blockedId);
        return { blocked };
      }),

    getBlockedIds: publicProcedure
      .input(z.object({ blockerId: z.string() }))
      .query(async ({ input }) => {
        return db.getBlockedIds(input.blockerId);
      }),
  }),
  // Text Messages router
  text: router({
    list: publicProcedure
      .input(z.object({ roomId: z.number() }))
      .query(async ({ input }) => {
        return db.listTextMessages(input.roomId);
      }),
    create: publicProcedure
      .input(z.object({
        roomId: z.number(),
        userId: z.string(),
        username: z.string(),
        text: z.string().min(1).max(300),
      }))
      .mutation(async ({ input }) => {
        const id = await db.addTextMessage(input);
        const now = new Date();
        emitTextMessageCreated(input.roomId, id, input.userId, input.username, input.text, now);
        return { id };
      }),
  }),
});
export type AppRouter = typeof appRouter;
